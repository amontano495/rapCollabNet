import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import sys
import pprint

client_credentials_manager = SpotifyClientCredentials(client_id='b522ba0a33df4fe5b09357c42a7edda9', client_secret='cf073ed6ddb043dda91c74e5773a3c3d')
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)


#artistName = str(sys.argv[1])
#artistID = 'spotify:artist:5K4W6rqBFWDnAN6FQUkS6x'

#results = sp.search(q=artistName,type='artist')
#artistID = results['artists']['items'][0]['uri'].split(':')[2]

#print 'Mining arist: ',artistName,' id: ',artistID

allRappers = list()
rapperListFile = open('rapperList','r')
for rapper in rapperListFile:
    allRappers.append(rapper)
    print rapper

allArtists = list()
nonRappers = list()
albumList = list()
trackList = list()
'''
acceptedGenres = ['hip hop','hip','rap','trap','underground hip hop','hip pop','trap music']
albumTypeList = ['album','single','appears_on','compilation']

for albumType in albumTypeList:
    results = sp.artist_albums(artistID,album_type=albumType)
    albums = results['items']
    while results['next']:
        results = sp.next(results)
        albums.extend(results['items'])

    for album in albums:
        #print 'ALBUM: ',album['name'],'-------------------'
        trackSearch = sp.album_tracks(album['id'])
        tracks = trackSearch['items']
        while trackSearch['next']:
            trackSearch = sp.next(trackSearch)
            tracks.extend(trackSearch['items'])

        for track in tracks:
            if track['name'] not in trackList:
                trackList.append(track['name'])
                artistSearch = track['artists']

                artistOnTrack = False
                for i in range(len(artistSearch)):
                    if artistName in artistSearch[i]['name']:
                        artistOnTrack = True
                        break

                if len(artistSearch) > 1 and artistOnTrack:
                    #print 'song: ',track['name'],'----'
                    #print 'Artists: '
                    for i in range(len(artistSearch)):
                        if artistSearch[i]['name'] not in allArtists and artistSearch[i]['name'] not in nonRappers:
                            #print artistSearch[i]['name']
                            artist = sp.artist(artistSearch[i]['id'])
                            #print artist['genres']
                            if (any(genre in artist['genres'] for genre in acceptedGenres) or artist['name'] in allRappers) and artistName not in artist['name']):
                                #print artist['name']
                                allArtists.append(artistSearch[i]['name'])
                            else:
                                print artist['name'],' aint a rapper'
                                print artist['genres']
                                nonRappers.append(artist['name'])


allArtists = list(set(allArtists))

for i in range(len(allArtists)):
    allArtists[i] = allArtists[i].encode('utf-8')
    print allArtists[i]
'''
